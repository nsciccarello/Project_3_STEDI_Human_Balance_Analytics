import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame

args = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# Load Accelerometer Trusted data from S3 and rename time column to "timestamp"
S3bucket_node1 = glueContext.create_dynamic_frame.from_options(
    format_options={"multiline": False},
    connection_type="s3",
    format="parquet",
    connection_options={
        "paths": ["s3://stedi-human-balance-analytics-project/trusted_zone/accelerometer_trusted/"]
    },
    transformation_ctx="S3bucket_node1",
)

S3bucket_node1 = S3bucket_node1.rename_field("<actual_column_name>", "timestamp")  # Adjust based on possible column variations

# Load Step Trainer Trusted data from S3 and rename time column to "sensorReadingTime"
AmazonS3_node1692030001186 = glueContext.create_dynamic_frame.from_options(
    format_options={"multiline": False},
    connection_type="s3",
    format="parquet",
    connection_options={
        "paths": ["s3://stedi-human-balance-analytics-project/trusted_zone/step_trainer_trusted/"]
    },
    transformation_ctx="AmazonS3_node1692030001186",
)

AmazonS3_node1692030001186 = AmazonS3_node1692030001186.rename_field("<actual_column_name>", "sensorReadingTime")  # Adjust as needed

# Perform Join operation on renamed columns
Join_node1692034397757 = Join.apply(
    frame1=S3bucket_node1,
    frame2=AmazonS3_node1692030001186,
    keys1=["timestamp"],
    keys2=["sensorReadingTime"],
    transformation_ctx="Join_node1692034397757",
)

# Drop unnecessary fields
DropFields_node1692034429091 = DropFields.apply(
    frame=Join_node1692034397757,
    paths=["user"],
    transformation_ctx="DropFields_node1692034429091",
)

# Write to S3 in Parquet format
S3bucket_node3 = glueContext.write_dynamic_frame.from_options(
    frame=DropFields_node1692034429091,
    connection_type="s3",
    format="parquet",
    connection_options={
        "path": "s3://stedi-human-balance-analytics-project/curated_zone/machine_learning_curated/",
        "partitionKeys": [],
    },
    transformation_ctx="S3bucket_node3",
)

job.commit()
